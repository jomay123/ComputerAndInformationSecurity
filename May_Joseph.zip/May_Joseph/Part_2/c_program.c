#include <stdio.h>

int main(int argc, char** argv)
{
   printf("Hello world from C\n");
   return 0;
}
